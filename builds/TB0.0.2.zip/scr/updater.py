import os
import requests
import json
from scr.settings import *

def checkForUpdates():
    r = requests.get(f'{GITHUB_REPO}/latest.json')
    latest_version = r.json()['version']

    if CURRENT_VERSION != latest_version:
        return True
    
def downloadUpdate():
    r = requests.get(f'{GITHUB_REPO}/latest.json')
    data = r.json()

    if "new" in data:
        for file_path in data["new"]:
            repo_path = f'{GITHUB_REPO}/{file_path}'
            local_path = f'{HOME_PATH}\\{file_path}'

            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            with open(local_path, 'wb') as f:
                r = requests.get(repo_path)
                f.write(r.content)

    if "deleted" in data:
        for file_path in data["deleted"]:
            local_path = f'{HOME_PATH}\\{file_path}'
            os.remove(local_path)
    
    if "replaced" in data:
        for file_path in data["replaced"]:
            repo_path = f'{GITHUB_REPO}/{file_path}'
            local_path = f'{HOME_PATH}\\{file_path}'

            r = requests.get(repo_path)
            with open(local_path, 'wb') as f:
                f.write(r.content)
    
    if "add_key_to_json" in data:
        for key in data["add_key_to_json"]:
            path = key["path"]
            key = key["key"]
            value = key["value"]

            with open(path, "r") as f:
                data = json.load(f)
            data[key] = value
            with open(path, "w") as f:
                f.write(json.dumps(data, indent=4))