from scr.updater import Updater

Updater.update()